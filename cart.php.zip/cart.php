<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link href="cart.css" rel="stylesheet">
  </head>
  <body class="bg">
    
    
    <div class="mt-1" style="height: 85px; width:100%; background-color:antiquewhite;">
      
      <h1 style="text-align: center;">Choise Your Seat
        <button class="btn btn-primary " type="submit"><a href="index.php" class="text-light">Back To Home </a> </button></h1> 
      
      
    </div>
    <div class="container">
      <div class="row">
      <div class=" joy col-4 mt-4" style="height: 580px; width: 25%;">
        
            <img src="pictures/1.jpg" class="rounded float-end" height="40px" width="40px"><br><br><br><br>
            <div>
              <button type="button" class="btn btn-info" >A-1</button>
              <button type="button" class="btn btn-info ">A-2</button>
              <button type="button" class="btn btn-info rounded float-end me-1">A-4</button>
              <button type="button" class="btn btn-info rounded float-end me-1">A-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">B-1</button>
        <button type="button" class="btn btn-info ">B-2</button>
        <button type="button" class="btn btn-info rounded float-end me-1">B-4</button>
        <button type="button" class="btn btn-info rounded float-end me-1">B-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">C-1</button>
        <button type="button" class="btn btn-info ">C-2</button>
        <button type="button" class="btn btn-info rounded float-end me-1">C-4</button>
        <button type="button" class="btn btn-info rounded float-end me-1">C-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">D-1</button>
        <button type="button" class="btn btn-info ">D-2</button>
        <button type="button" class="btn btn-info rounded float-end me-1">D-4</button>
        <button type="button" class="btn btn-info rounded float-end me-1">D-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">E-1</button>
        <button type="button" class="btn btn-info ">E-2</button>
        <button type="button" class="btn btn-info rounded float-end me-1">E-4</button>
        <button type="button" class="btn btn-info rounded float-end me-1">E-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">F-1</button>
        <button type="button" class="btn btn-info ">F-2</button>
        <button type="button" class="btn btn-info rounded float-end me-1">F-4</button>
        <button type="button" class="btn btn-info rounded float-end me-1">F-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">G-1</button>
        <button type="button" class="btn btn-info ">G-2</button>
        <button type="button" class="btn btn-info rounded float-end me-1">G-4</button>
        <button class="btn btn-info float-end me-1" type="button" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
          G-3
        </button>
       </div><br>
       <div class="text" style="height: 35px; width:100%;background-color: rgb(97, 97, 97);"> <p style="color:aliceblue;">Engine</p> </div>
           </div>
      <div class=" rounded float-end  col-8 mt-4"> 
        <div class="show_box joy1"> Your Selected Seat Details </div>
        <div class="table joy2"> 
          <table class="table table-dark table-striped-columns">
            <tr>
              <th>Bus Name</th>
              <th>Seat No.</th>
              <th>From</th>
              <th>To</th>
              <th>Amount</th>
              <th>Arrival Time</th>
            </tr>
            <tr>
              <td>Hanif</td>
              <td>G-3</td>
              <td>Gabtoli</td>
              <td>Rajshahi</td>
              <td>850.00 Tk</td>
              <td>09.20 pm Hours</td>

            </tr>
          </tabe>
          
        </div>

        <!-- <div style="min-height: 120px;">
          <div class=" mt-4 collapse collapse-horizontal" id="collapseWidthExample">
            <div class="card card-body" style="width: 760px;">
             <h2> Seat name : G-3 </h2>                                      <br><hr>
             <h2> Seat Price:  980.00 Tk   </h2>                                     <br><hr>
            </div>
          </div>
        </div> -->
    </div>
    </div>
    </div>
   
    
  
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>