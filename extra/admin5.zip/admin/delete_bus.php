<?php
include '../config.php';
session_start ();
if(!isset($_SESSION["login"])){

	header("location:../login.php"); 

}

$id=$_GET['busId'];
$sql="DELETE from busTable where busId='$id'";
$query= mysqli_query($conn, $sql);
header("Location:bus_list.php");
?>