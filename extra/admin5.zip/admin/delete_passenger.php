<?php
include '../config.php';
session_start ();
if(!isset($_SESSION["login"])){

	header("location:../login.php"); 

}

$id=$_GET['passengerId'];
$sql="DELETE from passengerTable where passengerId='$id'";
$query= mysqli_query($conn, $sql);
header("Location:passenger_list.php");
?>