<?php

include 'config.php';
$statusMsg = '';

$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);



if(isset($_POST['submit'] )){
$allowTypes = array('jpg','png','jpeg','gif','pdf');
    if(in_array($fileType, $allowTypes)){
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
            $insert = $db->query("INSERT into agentTable (nidUpload) VALUES ($fileName");
        }
        
    }
$key = "AID-";
$year = date("Y");
$month = date("m");
$day = date("d");
$letter = chr(rand(65,90));

$ticket=rand(1000,9999);
$fnl=$key.$year.$month.$day.$letter.$ticket;
        
        
        $agentId =$fnl;
        $agentName = $_POST['agentName'];
        $phoneNo = $_POST['phoneNo'];
        $companyName = $_POST['companyName'];
        $nid = $_POST['nid'];
        $nidUpload = $_POST['nidUpload'];
        $picture = $_POST['picture'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $address2 = $_POST['address2'];
        $country = $_POST['country'];
        $city = $_POST['city'];
        $zip = $_POST['zip'];
        $district = $_POST['district'];
        $gender = $_POST['gender'];
        $agentStatus = $_POST['agentStatus'];


        $sql = "INSERT INTO agentTable(agentId, agentName, phoneNo, companyName, nid, nidUpload, picture, email, password, address, address2, country, city, zip, district, gender, agentStatus) VALUES ($agentId,$agentName,$phoneNo,$companyName,$nid,$nidUpload,$picture,$email,$password,$address,$address2,$country,$city,$zip,$district,$gender,$agentStatus);";




        $request = mysqli_query($conn, $sql);

        if($request){
            header("Location:add_agent.php");
        }else{
            echo "Failed: ". mysqli_error($conn);
        }

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP CRUD Application</title>

    <!-- bootstrap CSS -->
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    

    <div class="container mt-3">
        <div class="text-center mb-4 mt-3">
            <h3>Add New Agent Accounts</h3>
            <p class="text-muted">Complete the form below to add a new user</p>
        </div>

        <div class="container d-flex justify-content-center">
            <form action="" method="post" style="width: 30vh; min-width: 800px;">
                <div class="row">
                    
                    <div  class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="agentName" placeholder="Agent Name">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="phoneNo" placeholder="Phone No">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="companyName"  placeholder="Company Name">
                    </div>
                    <div class="mb-2 col-md-6" >
                        <input type="text" class="form-control" name="nid" placeholder="Nid">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="file" class="form-control" name="nidUpload" placeholder="Nid Upload">
                    </div>
                    <div class="mb-2">
                        <input type="text" class="form-control" name="picture"  placeholder="Picture">
                    </div>
                    <div class="mb-2 col-md-6" >
                        <input type="email" class="form-control" name="email" placeholder="Email">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    
                    <div class="mb-2">
                        <textarea name="address" placeholder="Address" id="" cols="105" rows="2"></textarea>
                        <!-- <input type="text" class="form-control" name="name"  placeholder=""> -->
                    </div>
                    <div  class="mb-2">
                        <textarea name="address2" placeholder="Address" id="" cols="105" rows="2"></textarea>
                        <!-- <input type="text" class="form-control" name="month" placeholder=""> -->
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="country" placeholder="Country">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="city"  placeholder="City">
                    </div>
                    <div  class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="zip" placeholder="Zip Code">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="district" placeholder="District">
                    </div>
                    <div  class="mb-2">
                        <label for="gender"><strong>Gender:</strong></label>
                        Male
                        <input type="radio" class="" name="gender" value="Male">
                        Female
                        <input type="radio" class="" name="gender" value="Female">
                    </div>
                    <div class="mb-2">
                        <input type="number" class="form-control" name="agentStatus" placeholder="Agent Status">
                    </div>
                    
                    
                    <div class="mt-4">
                        <button type="submit" name="submit" class="btn btn-success">SAVE</button>
                        <a href="view.php" class="btn btn-danger">Cancel</a>
                        <br><br>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

        