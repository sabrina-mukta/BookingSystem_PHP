<?php
$servername = "localhost";
$username = "itservtc_bs";
$password = "_O{u}4BN0i;4";

$conn = mysqli_connect($servername, $username, $password,'itservtc_bs');
// Check connection
// if (!$conn) {
//   die("Connection failed: " . mysqli_connect_error());
// }
// if($conn==true){
//     echo "Successfully connected";
// }



?>