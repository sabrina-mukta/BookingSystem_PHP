<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link href="../New folder/style.css" rel="stylesheet">
  </head>
  <body>
    
    <div class="mt-4" style="height: 65px; width:100%; background-color:antiquewhite;">
      <h1 style="text-align: center;">Choise Your Seat</h1> 
    </div>
    <div class="container col-12">
      <div class=" joy col-4 mt-4 float-left" style="height: 580px; ">
        
            <img src="../New folder/1.jpg" class="rounded float-end" height="40px" width="40px"><br><br><br><br>
            <div>
              <button type="button" class="btn btn-info">A-1</button>
              <button type="button" class="btn btn-info ">A-2</button>
              <button type="button" class="btn btn-info rounded float-end ">A-4</button>
              <button type="button" class="btn btn-info rounded float-end ">A-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">B-1</button>
        <button type="button" class="btn btn-info ">B-2</button>
        <button type="button" class="btn btn-info rounded float-end ">B-4</button>
        <button type="button" class="btn btn-info rounded float-end ">B-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">C-1</button>
        <button type="button" class="btn btn-info ">C-2</button>
        <button type="button" class="btn btn-info rounded float-end ">C-4</button>
        <button type="button" class="btn btn-info rounded float-end ">C-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">D-1</button>
        <button type="button" class="btn btn-info ">D-2</button>
        <button type="button" class="btn btn-info rounded float-end ">D-4</button>
        <button type="button" class="btn btn-info rounded float-end ">D-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">E-1</button>
        <button type="button" class="btn btn-info ">E-2</button>
        <button type="button" class="btn btn-info rounded float-end ">E-4</button>
        <button type="button" class="btn btn-info rounded float-end ">E-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">F-1</button>
        <button type="button" class="btn btn-info ">F-2</button>
        <button type="button" class="btn btn-info rounded float-end ">F-4</button>
        <button type="button" class="btn btn-info rounded float-end ">F-3</button>
       </div><br>
       <div>
        <button type="button" class="btn btn-info">G-1</button>
        <button type="button" class="btn btn-info ">G-2</button>
        <button type="button" class="btn btn-info rounded float-end ">G-4</button>
        <button type="button" class="btn btn-info rounded float-end ">G-3</button>
       </div><br>
       <div class="text" style="height: 35px; width:100%;background-color: rgb(139, 136, 136);"> <p>Engine</p> </div>
           </div>
      <div class=" float-right joy1 col-8 mt-4"> 
       

      </div>

    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>
