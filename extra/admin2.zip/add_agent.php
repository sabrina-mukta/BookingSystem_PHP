<?php

include '../config.php';
if(isset($_POST['submit'] )){

// $pname = rand(1000,10000)."-".$_FILES["nidUpload"]["name"];
// $tname = $_FILES["nidUpload"]["tmp_name"];
// $uploads_dir = 'images';
// move_uploaded_file($tname, $uploads_dir.'/'.$pname);
// $nName = rand(1000,10000)."-".$_FILES["picture"]["name"];
// $tName = $_FILES["picture"]["tmp_name"];
// $uploads_dir = 'images';
// move_uploaded_file($tName, $uploads_dir.'/'.$nName);
    $dir='pictures/';

    $path=$dir.basename($_FILES['nidUpload']['name']);
    $tmp=$_FILES['nidUpload']['tmp_name'];
    $type=$_FILES['nidUpload']['type'];
    $size=$_FILES['nidUpload']['size'];
    $error=$_FILES['nidUpload']['error'];
    
    $path1=$dir.basename($_FILES['picture']['name']);
    $tmp1=$_FILES['picture']['tmp_name'];
    $type1=$_FILES['picture']['type'];
    $size1=$_FILES['picture']['size'];
    $error1=$_FILES['picture']['error'];

$key = "AID-";
$year = date("Y");
$month = date("m");
$day = date("d");
$letter = chr(rand(65,90));

$ticket=rand(1000,9999);
$fnl=$key.$year.$month.$day.$letter.$ticket;
        
        
        $agentId =$fnl;
        $agentName = $_POST['agentName'];
        $phoneNo = $_POST['phoneNo'];
        $companyName = $_POST['companyName'];
        $nid = $_POST['nid'];
        $nidUpload = $path;
        $picture = $path1;
        $email = $_POST['email'];
        $password1 = $_POST['password'];
        $address1 = $_POST['address'];
        $address2 = $_POST['address2'];
        $country = $_POST['country'];
        $city = $_POST['city'];
        $zip = $_POST['zip'];
        $district = $_POST['district'];
        $gender = $_POST['gender'];
        $agentStatus = $_POST['agentStatus'];


        $sql =" CALL insertAgentTable('$agentId','$agentName',$phoneNo,'$companyName',$nid,'$nidUpload','$picture','$email','$password1','$address1','$address2','$country','$city','$zip','$district','$gender','$agentStatus');";
        $request = mysqli_query($conn, $sql);
        

        if($request){
            header("Location:add_agent.php");
        }else{
            echo "Failed: ". mysqli_error($conn);
        }

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP CRUD Application</title>

    <!-- bootstrap CSS -->
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="offcanvas offcanvas-start sidebar-nav bg-light text-dark " id="sidebar">
        <div class="offcanvas-body p-0 flex-grow-0 ">
            <center>

                <a class="btn btn-dark w-100  text-light" href="dashboard.php" role="button" aria-expanded="false" aria-controls="collapseExample">Dashboard</a>
            </center>
      

        <!-----------Bus start--------------->
        <center><a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#busId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Bus</a></center>

        <div class="collapse" id="busId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="bus_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">BUS LIST</a>
                <a class=" dropdown-item text-start " href="add_bus.php " style="background-color: ivory ;" onmouseover="this.style.color='#00FF00'" onmouseout="this.style.color='#000'">Add Bus</a>
                <a class="dropdown-item text-start " href="update_bus.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Bus Info</a>
            </div>


        </div>
        <!-----------Bus End--------------->

        <!-----------Route Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#routeId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Route line</a>
        </center>

        <div class="collapse" id="routeId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="route_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00'" onmouseout="this.style.color='#000'">Route List</a>
                <a class=" dropdown-item text-start " href="add_route.php " style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Route</a>
                <a class="dropdown-item text-start " href="update_route.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Route</a>
            </div>
        </div>
        <!-----------route End--------------->
        <!-----------Booking Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#bookingId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Booking System</a>
        </center>

        <div class="collapse" id="bookingId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="booking_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Booking List</a>
                <a class=" dropdown-item text-start " href="add_booking.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Booking</a>
                <a class="dropdown-item text-start " href="update_booking.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Booking</a>
            </div>
        </div>
        <!-----------Booking End--------------->
        <!-----------user Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#userId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">User</a>
        </center>

        <div class="collapse" id="userId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="agent_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00'" onmouseout="this.style.color='#000'">Agent List</a>
                <a class=" dropdown-item text-start " href="add_agent.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00'" onmouseout="this.style.color='#000'">Add Agent</a>
                <a class="dropdown-item text-start " href="update_agent.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Agent Info</a>
            </div>
        </div>
        <!-----------User End--------------->
        <!-----------refund Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#refundId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Refund</a>
        </center>

        <div class="collapse" id="refundId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="refund_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Refund List</a>
                <a class=" dropdown-item text-start " href="add_refund.php " style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Refund</a>
                <a class="dropdown-item text-start " href="update_refund.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Refund Info</a>
            </div>
        </div>
        <!-----------User End--------------->
        <!-----------account Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#accId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Account</a>
        </center>

        <div class="collapse" id="accId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="account_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Account list</a>
                <a class=" dropdown-item text-start " href="add_account.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Account</a>
                <a class="dropdown-item text-start " href="update_account.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Account Info</a>
            </div>
        </div>
        <!-----------account  End--------------->
        <!-----------Counter Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#counterId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Counter</a>
        </center>

        <div class="collapse" id="counterId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="counter_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Counter LIST</a>
                <a class=" dropdown-item text-start " href="add_counter.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Counter</a>
                <a class="dropdown-item text-start " href="update_counter.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Counter Info</a>
            </div>
        </div>
        <!-----------User End--------------->
        <!-----------Feedback Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#feedId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Feedback</a>
        </center>

        <div class="collapse" id="feedId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="feedback_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Feedback LIST</a>
                <a class=" dropdown-item text-start " href="add_feedback.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Feedback</a>
                <a class="dropdown-item text-start " href="update_feedback.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Feedback Info</a>
            </div>
        </div>
        <!-----------counter End--------------->
        <!-----------Customer Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#pId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Passenger </a>
        </center>

        <div class="collapse" id="pId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="passenger_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Passenger List</a>
                <a class=" dropdown-item text-start " href="add_passenger.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Passenger</a>
                <a class="dropdown-item text-start " href="update_passenger.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Customer Info</a>
            </div>
        </div>
        <!-----------Customer  End--------------->
        <!-----------Discount Start--------------->
        <center>
            <a class="btn btn-primary p-1 m-1 " data-bs-toggle="collapse" href="#discountId" role="button" aria-expanded="false" aria-controls="collapseExample" style="width:90% ;">Discount </a>
        </center>

        <div class="collapse" id="discountId">
            <div class="bg-light text-dark p-1 m-1">
                <a class="dropdown-item text-start" href="discount_list.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add discount</a>
                <a class=" dropdown-item text-start " href="add_discount.php " style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Add Discount</a>
                <a class="dropdown-item text-start " href="update_discount.php" style="background-color: ivory ;" onmouseover="this.style.color='#00FF00	'" onmouseout="this.style.color='#000'">Update Discount Info</a>
            </div>
        </div>
        <!-----------Discount  End--------------->
    </div>
    </div>


    <div class="container mt-3">
        <div class="text-center mb-4 mt-3 pt-2">
            <h3>Add New Agent Accounts</h3>
            <p class="text-muted">Complete the form below to add a new user</p>
        </div>

        <div class="container d-flex justify-content-center">
            <form action="" method="post" style="width: 30vh; min-width: 800px;">
                <div class="row">
                    
                    <div  class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="agentName" placeholder="Agent Name">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="phoneNo" placeholder="Phone No">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="companyName"  placeholder="Company Name">
                    </div>
                    <div class="mb-2 col-md-6" >
                        <input type="text" class="form-control" name="nid" placeholder="Nid">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="file" class="form-control" name="nidUpload" placeholder="Nid Upload">
                    </div>
                    <div class="mb-2">
                        <input type="file" class="form-control" name="picture"  placeholder="Picture">
                    </div>
                    <div class="mb-2 col-md-6" >
                        <input type="email" class="form-control" name="email" placeholder="Email">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    
                    <div class="mb-2">
                        <textarea name="address" placeholder="Address" id="" cols="105" rows="2"></textarea>
                        <!-- <input type="text" class="form-control" name="name"  placeholder=""> -->
                    </div>
                    <div  class="mb-2">
                        <textarea name="address2" placeholder="Address" id="" cols="105" rows="2"></textarea>
                        <!-- <input type="text" class="form-control" name="month" placeholder=""> -->
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="country" placeholder="Country">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="city"  placeholder="City">
                    </div>
                    <div  class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="zip" placeholder="Zip Code">
                    </div>
                    <div class="mb-2 col-md-6">
                        <input type="text" class="form-control" name="district" placeholder="District">
                    </div>
                    <div  class="mb-2">
                        <label for="gender"><strong>Gender:</strong></label>
                        Male
                        <input type="radio" class="" name="gender" value="Male">
                        Female
                        <input type="radio" class="" name="gender" value="Female">
                    </div>
                    <div class="mb-2">
                        <input type="number" class="form-control" name="agentStatus" placeholder="Agent Status">
                    </div>
                    
                    
                    <div class="mt-4">
                        <button type="submit" name="submit" class="btn btn-success">SAVE</button>
                        <a href="view.php" class="btn btn-danger">Cancel</a>
                        <br><br>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

        