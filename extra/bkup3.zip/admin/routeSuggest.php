<?php 
include '../config.php';

if ($a=isset($_GET['routeId'])) {
                                                 
$query = "SELECT * FROM route WHERE routeId LIKE '{$_GET[$a]}%' LIMIT 25";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
                while ($user = mysqli_fetch_array($result)) {
                $res[] = $user['routeId'];
                }
                                                } else {
                                                  $res = array();
                                                }
                                                //return json res
                                                echo json_encode($res);
                                            }
                                    ?>