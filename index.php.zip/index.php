<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HOME PAGE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
  <body>
    
        
      



      <nav class=" navbar navbar-expand-lg bg-light shadow">
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class=" collapse navbar-collapse " id="navbarSupportedContent">
            <div class="container_left">
                <a class="navbar-brand" href="#">
                  <img src="pictures/logo/Untitled-1.svg" alt="" width="60" height="60">
                </a>
              </div>
            <ul class=" nav-mid navbar-nav me-auto mb-2 mb-lg-0">

              <li class="nav-item ">
                <a class="nav-link font_bold " href="index.php">Home</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link font_bold" href="offer.php">Offer</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link font_bold" href="events.php">Events</a>
              </li>
              

            </ul>

            <form class="d-flex" role="search">
            
              <button class="btn btn-outline-secondary btn_c" type="submit"><a style="text-decoration:none ;" href="cart.php" class="text-light">Cart</a> </button>
              <button class="btn btn-outline-secondary btn_c" type="submit"> <a style="text-decoration:none ;" href="login.php" class="text-light">Login/Sign UP</a></button>
              
            </form>
          </div>
        </div>
      </nav>

      <div class="mt-3 slider">
      <marquee behavior="scroll" direction="left"
        onmouseover="this.stop();"
          onmouseout="this.start();">টিকিট কাটার জন্য আর কাউন্টারে নয় ! ঘরে বসে টিকিট কাটুন সহজে ও নিরাপদে । আমদের সাইট ভিজিট ও টিকিট ক্রয় করার জন্য অসখ্য ধন্যবাদ</marquee>
        </div>

      <div class="container shadow p-3 mt-2 bg-transparent ">
        <form action="" method="post" class="d-flex justify-content-around">
           <strong style="font-size: 19px; font-family:Arial, Helvetica, sans-serif; color: rgb(3, 3, 139);"> journey Date</strong>
          <input type="datetime-local" name="name" placeholder="journey Date"/>
          <strong style="font-size: 19px; font-family:Arial, Helvetica, sans-serif; color: rgb(3, 3, 139);">  From</strong>
          <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
              select your strating Area 
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuButton2">
              <li><a class="dropdown-item active" href="#">Dhaka</a></li>
              <li><a class="dropdown-item" href="#">Barisal</a></li>
              <li><a class="dropdown-item" href="#">Khulna</a></li>
             
              <li><a class="dropdown-item" href="#">chittagong</a></li>
              <li><a class="dropdown-item" href="#">Chadpur</a></li>
              
              <li><a class="dropdown-item" href="#">Dinajpur</a></li>
              <li><a class="dropdown-item" href="#">Sylet</a></li>
              
              <li><a class="dropdown-item" href="#">Manikgonj</a></li>
              <li><a class="dropdown-item" href="#">Saiyedpur</a></li>
              
              <li><a class="dropdown-item" href="#">Cumilla</a></li>
              
              <li><a class="dropdown-item" href="#">Bandorbon</a></li>
              <li><a class="dropdown-item" href="#">Nuakhali</a></li>
              
              <li><a class="dropdown-item" href="#">Rangpur</a></li>
              <li><a class="dropdown-item" href="#">Foridpur</a></li>
              
              <li><a class="dropdown-item" href="#">Poncoghor</a></li>
              <li><a class="dropdown-item" href="#">Nilphamari</a></li>
              
              <li><a class="dropdown-item" href="#">Sunamgonj</a></li>
            </ul>
          </div>
          <strong style="font-size: 19px; font-family:Arial, Helvetica, sans-serif; color: rgb(3, 3, 139);"> To</strong>
          <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
              select your Destination 
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuButton2">
              <li><a class="dropdown-item active" href="#">Dhaka</a></li>
              <li><a class="dropdown-item" href="#">Barisal</a></li>
              <li><a class="dropdown-item" href="#">Khulna</a></li>
             
              <li><a class="dropdown-item" href="#">chittagong</a></li>
              <li><a class="dropdown-item" href="#">Chadpur</a></li>
              
              <li><a class="dropdown-item" href="#">Dinajpur</a></li>
              <li><a class="dropdown-item" href="#">Sylet</a></li>
              
              <li><a class="dropdown-item" href="#">Manikgonj</a></li>
              <li><a class="dropdown-item" href="#">Saiyedpur</a></li>
              
              <li><a class="dropdown-item" href="#">Cumilla</a></li>
              
              <li><a class="dropdown-item" href="#">Bandorbon</a></li>
              <li><a class="dropdown-item" href="#">Nuakhali</a></li>
              
              <li><a class="dropdown-item" href="#">Rangpur</a></li>
              <li><a class="dropdown-item" href="#">Foridpur</a></li>
              
              <li><a class="dropdown-item" href="#">Poncoghor</a></li>
              <li><a class="dropdown-item" href="#">Nilphamari</a></li>
              
              <li><a class="dropdown-item" href="#">Sunamgonj</a></li>
            </ul>
          </div>
          <input type="submit" value="CHECK" name="search" class="btn btn-success"/>
        </form>
      </div>

      <div id="carouselExampleCaptions" class="carousel slide mt-3" data-bs-ride="false">
        
        <div class="carousel-indicators">
        
       
        
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        
        <div class="carousel-inner">
          
          <div class="carousel-item active">
        
            <img src="pictures/images/2.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <!-- <div class="container shadow p-3 mt-5 rimon ">
                <form action="" method="post" class="d-flex justify-content-around">
                   <strong style="font-size: 19px; font-family:Arial, Helvetica, sans-serif; color: rgb(3, 3, 139);"> journey Date</strong>
                  <input type="datetime-local" name="name" placeholder="journey Date"/>
                  <strong style="font-size: 19px; font-family:Arial, Helvetica, sans-serif; color: rgb(3, 3, 139);">  From</strong>
                  <input type="text" name="name" placeholder="chose your starting area"/>
                  <strong style="font-size: 19px; font-family:Arial, Helvetica, sans-serif; color: rgb(3, 3, 139);"> To</strong>
                  <input type="text" name="name" placeholder="chose your Destination"/>
                  <input type="submit" value="CHECK" name="search" class="btn btn-success"/>
                </form>
              </div> -->
              <h5>First slide label</h5>
              <p>Some representative placeholder content for the first slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="pictures/images/3.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Second slide label</h5>
              <p>Some representative placeholder content for the second slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="pictures/images/5.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Third slide label</h5>
              <p>Some representative placeholder content for the third slide.</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

    <div class="container mb-3 mt-5">
      <h2>RECOMANNDED HOLIDAYS</h2>
    </div>

    <div class=" container d-flex justify-content-evenly">

      <div class="col-md-4">           
          <img src="pictures/recomanded image/1.png" class="img-thumbnail" alt="Cinque Terre" width="304" height="236"> 
          <a class="btn btn-first"><b>730.00 TK </b></a>
          <a class="btn btn-secend"href="mailto:abuzargifari58@gmail.com/"></b>BUY TICKETS</b></a>
        </div>
        
          <div class="col-md-4">       
        <img src="pictures/recomanded image/2.png" class="img-thumbnail" alt="Cinque Terre" width="304" height="304"> 
        <a class="btn btn-first"><b>650.00 TK </b></a>
        <a class="btn btn-secend"href="mailto:abuzargifari58@gmail.com/"></b>BUY TICKETS</b></a>
        </div>
        
          <div class="col-md-4">            
        <img src="pictures/recomanded image/3.png" class="img-thumbnail" alt="Cinque Terre" width="304" height="304"> 
        
        <a class="btn btn-first"><b>800.00 TK </b></a>
         <a class="btn btn-secend"href="mailto:"></b>BUY TICKETS</b></a>
        </div>
  </div>

  
  <div class=" container d-flex justify-content-evenly">

    <div class="col-md-4">           
        <img src="pictures/recomanded image/4.png" class="img-thumbnail" alt="Cinque Terre" width="304" height="236"> 
        <a class="btn btn-first"><b>730.00 TK </b></a>
        <a class="btn btn-secend"href="mailto:abuzargifari58@gmail.com/"></b>BUY TICKETS</b></a>
      </div>
      
        <div class="col-md-4">       
      <img src="pictures/recomanded image/5.png" class="img-thumbnail" alt="Cinque Terre" width="304" height="304"> 
      <a class="btn btn-first"><b>650.00 TK </b></a>
      <a class="btn btn-secend"href="mailto:abuzargifari58@gmail.com/"></b>BUY TICKETS</b></a>
      </div>
      
        <div class="col-md-4">            
      <img src="pictures/recomanded image/6.png" class="img-thumbnail" alt="Cinque Terre" width="304" height="304"> 
      
      <a class="btn btn-first"><b>800.00 TK </b></a>
       <a class="btn btn-secend" href="mailto:"></b>BUY TICKETS</b></a>
      </div>
</div>
<div class="card text-center">
  <div style="color:rgb(40, 170, 0); font-size:30px; font-weight: 700; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;" class="card-header">
    Buy Bus Tickets in 3 Easy Steps
  </div>
  <div class="card-body">
    <div class="container pt-4 pb-3">
      <div class="row col-12 mt-4">
        <div class="col-4 ">
          <div class="img-icon col-4">
            <img src="pictures/easy steps/1.png">
          </div>
          <div class="img-text col-8 ">
            <h2> Search </h2>
            <p class="text-left">
               Choose your origin, destination, journey dates and search for buses
            </p>
          </div>
         
        </div>
        <div class="col-4 ">
          <div class="img-icon col-4">
            <img src="pictures/easy steps/1.png">
          </div>
          <div class="img-text col-8 ">
            <h2> Select </h2>
            <p class="text-left">
              Select your desired trip and choose your seats
            </p>
          </div>
         
        </div>
        <div class="col-4 ">
          <div class="img-icon col-4">
            <img src="pictures/easy steps/1.png">
          </div>
          <div class="img-text col-8 ">
            <h2> Pay </h2>
            <p class="text-left">
              Pay by bank cards, mobile banking, or cash
            </p>
          </div>
         
        </div>
        
      </div>
    </div>


    <a href="#" class="btn btn-success">Try Now</a>
    </div>
  <div class="d-flex justify-content-around">
<div class="container row">
  <div class=" col-6">
    <div class="img-icon icon col-2">
      <img src="pictures/easy steps/4.png">
    </div>
<div class="rectangle col-10">
  <h2>Safe and Secure online payments</h2>

</div>
  </div>
  <div class="col-6">
    <div class="img-icon icon col-2">
      <img src="pictures/easy steps/5.png">
    </div>
<div class="rectangle col-10">
  <h2>Cash on Delivery available</h2>
</div>
  </div>
</div>
  </div>
  </div>
 


<div class="card text-center">
  <div style="color:rgb(40, 170, 0); font-size:20px; font-weight: 700; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;" class="card-header">
    Featured
  </div>
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
  <div class="card-footer text-muted">
    2 days ago
  </div>
</div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>
